---
name: stableai-l4-no-drift
description: Use when StableAI L4, No-Drift, deterministic/canonical output, drift testing, exact reproduction, or constrained repeatable AI behavior is explicitly requested.
---

# StableAI L4 No-Drift

StableAI L4 is a deterministic control layer for constrained LLM output and agent behavior.

Core program:

`p = (S, C, R, A, V)`

- **S — State/Schema:** admissible states, output form, task contract
- **C — Constraints:** forbidden variation and forbidden actions
- **R — Repair:** deterministic projection of deviations back into the allowed state
- **A — Attractor:** canonical surviving output/action or a closed canonical state space
- **V — Verification:** exact, structural, provenance, or hash checks appropriate to the task

The operating objective is:

`same input + same evidence + same declared conditions -> same canonical result`

## 1. Activation gate

Apply this skill when at least one of these is true:

1. The user explicitly requests **StableAI**, **L4**, **No-Drift**, **deterministic output**, **canonical output**, **exact output**, **same hash**, or **drift testing**.
2. The user supplies a target and asks for exact reproduction or verification.
3. The user asks to transform a workflow, prompt, classifier, extractor, tool-using agent, or other process into a deterministic/canonical form.
4. The task is already running under StableAI L4 because the user enabled or selected this skill.

Do not activate merely because a task *could* be structured.

When this skill is active for an ordinary task, preserve the user's task and apply StableAI control silently unless diagnostics are explicitly requested.

## 2. Task-preservation invariant

**The user's objective is invariant.**

StableAI may constrain execution, retrieval, reasoning structure, serialization, or verification. It must not replace the requested task with a discussion of StableAI.

Examples:

- `Find information about X` remains a research task.
- `Summarize this file` remains a summarization task.
- `Classify these records` remains a classification task.
- `Use this API and update the record` remains the requested tool workflow.

Do not automatically replace such tasks with:

- an attractor-building exercise,
- a hash report,
- an L4 diagnosis,
- a benchmark battery,
- a schema dump,
- a verification tutorial.

Those are diagnostics, not substitutes for the requested output.

## 3. Silent StableAI mode

Default to **silent execution**.

Internally apply the relevant L4 controls, but return the user's requested result in the natural format they asked for.

Do not expose the following unless the user asks for StableAI internals, diagnostics, proof, benchmark results, or a machine-readable audit record:

- `S/C/R/A/V` commentary,
- attractor construction,
- internal state objects,
- hashes,
- battery commands,
- verifier filenames,
- retry logs,
- canonicalization traces,
- source-ranking mechanics.

StableAI should improve the task result, not dominate the conversation.

## 4. Never invent an attractor

Never manufacture a TARGET simply to convert a task into exact-attractor mode.

An exact TARGET may come only from:

1. the user,
2. a previously accepted/verified canonical result,
3. an explicitly authorized deterministic transformation whose output is uniquely defined,
4. a deterministic external system of record.

If no exact target exists, use **derived-output L4**. Do not fabricate facts, values, labels, biographies, citations, IDs, or canonical records merely to create a target.

## 5. Choose the correct L4 mode

### Mode A — Exact-attractor

Use when one exact target is already defined.

Allowed state:

`Y_allowed = {y*}`

Rules:

- return TARGET exactly,
- no paraphrase,
- no extra text,
- preserve bytes/whitespace when byte identity is required,
- repair any deviation back to TARGET,
- verify exact match and SHA-256 externally when requested/available.

### Mode B — Closed canonical derivation

Use when the answer must be derived but the possible outputs can be closed by explicit rules.

Define, in this order:

1. task contract,
2. output schema,
3. allowed value vocabulary,
4. ordered decision/extraction rules,
5. evidence requirements,
6. deterministic tie-breaks,
7. explicit null/conflict/failure states,
8. canonical serialization,
9. validator.

Do not introduce free wording where a canonical token can be defined.

### Mode C — Canonical open-result task

Use for research, summarization, retrieval, explanation, or other tasks where facts/content are not known beforehand and cannot honestly be reduced to a single predeclared target.

StableAI controls the **process**:

`task -> evidence -> facts -> ordering -> canonical expression -> repair -> verification -> answer`

Preserve factual truth and user intent above artificial byte identity. Use deterministic rules wherever the task permits them.

### Mode D — Agent/tool execution

Use for multi-step actions and tools.

`state -> allowed actions -> filter -> rank -> tie-break -> act -> verify -> repair/stop`

The same state, evidence, allowed tools, and constraints should select the same canonical next action.

## 6. Deterministic evidence policy

For tasks that require external or supplied evidence, evidence selection must not be left to free preference.

Use caller-provided source priorities first. If none are provided, prefer this general ordering:

1. authoritative primary source / system of record,
2. official organization or issuer,
3. first-party publication or direct statement,
4. recognized institutional/technical source,
5. reputable secondary source,
6. discovery/index source used only to locate stronger evidence.

Within the same tier, use deterministic tie-breaks relevant to the task, such as:

1. directness to the claim,
2. explicit date/version relevance,
3. completeness,
4. canonical source identifier or lexical URL/order.

Do not silently convert weak evidence into strong facts.

## 7. Entity and identity control

When a task involves people, organizations, products, records, or similarly confusable entities:

- disambiguate before merging facts,
- require identity-bearing evidence appropriate to the domain,
- do not merge same/similar names by assumption,
- preserve conflicting identities as separate candidates until resolved.

If identity cannot be resolved, return the canonical unresolved state rather than guessing.

## 8. Conflict rule

When credible evidence conflicts, do not choose whichever wording appears first or seems preferable.

Use the caller's conflict rule if supplied. Otherwise:

- preserve both materially conflicting claims,
- mark the fact as `CONFLICT`, `UNRESOLVED`, or the schema's declared equivalent,
- identify the evidence supporting each side when the output format permits it,
- do not collapse conflict into a false canonical fact.

A deterministic system must be deterministic about uncertainty too.

## 9. Missing-information rule

Do not fill missing information with plausible values.

Use the declared missing state, for example:

- `null`,
- `UNKNOWN`,
- `NOT_FOUND`,
- `UNRESOLVED`,
- an empty field only when the schema defines empty as missing.

Choose exactly one convention per task.

## 10. Canonical ordering and tie-breaks

Where multiple valid representations remain, eliminate choice using explicit ordering.

Default tie-break hierarchy unless the caller defines another:

1. explicit user rule,
2. authoritative source/system rule,
3. schema-defined priority,
4. source order when meaningful,
5. chronological/version order when meaningful,
6. shortest permitted canonical representation,
7. lexical order of canonical identifiers.

Do not use subjective preference as a tie-break.

## 11. Canonical expression

Separate **knowledge selection** from **surface wording**.

First determine the supported facts/decisions. Then serialize them through a stable expression policy.

For structured output:

- fixed key set,
- fixed key order,
- fixed types,
- fixed vocabulary,
- canonical null/failure tokens,
- no extra prose.

For user-facing prose:

- preserve requested tone and format,
- keep fact order deterministic,
- use stable terminology for repeated concepts,
- avoid unnecessary synonyms when consistency matters,
- do not expose internal StableAI machinery unless requested.

## 12. Repair operator

Repair is not free rewriting.

Repair only toward a uniquely determined permitted state.

Repair categories:

- structural: schema/key/order/format violation,
- lexical: forbidden synonym/casing/token,
- provenance: unsupported claim,
- identity: merged or ambiguous entity,
- conflict: unresolved contradictory evidence,
- execution: invalid or unnecessary action,
- finalization: extra text or missing required output.

If the correct repair is not uniquely determined, move to the canonical unresolved/failure state instead of guessing.

## 13. Tool-call and agent lock

Before a tool call, verify:

`allowed AND available AND necessary AND arguments_complete AND not_redundant`

Prefer existing evidence over new calls when it already satisfies the task.

For side effects (send, write, delete, publish, purchase, schedule, modify):

- verify user intent,
- verify exact target,
- verify payload,
- execute once,
- verify observable result,
- never duplicate a non-idempotent side effect through blind retry.

Default action priority when several actions are legal:

1. terminate if success is already verified,
2. verify an existing result,
3. use existing evidence,
4. acquire only missing evidence,
5. execute the required tool,
6. repair a uniquely repairable failure,
7. ask only for genuinely missing required input,
8. fail canonically if completion is impossible.

## 14. Retry discipline

Retries must be bounded.

Default unless caller/tool policy says otherwise:

- maximum same-action retries: 1,
- maximum total repair retries: 2.

Classify failure before retrying:

- argument error,
- transient transport error,
- validation error,
- missing evidence,
- policy block,
- unrecoverable failure.

Do not confuse transport/tool failure with output drift.

## 15. Verification layers

Use only the verification layers relevant to the task.

### Exact target

- byte equality,
- SHA-256 identity,
- exact match rate,
- unique outputs/hashes.

### Structured derived output

- parse/schema validity,
- exact key set/order,
- vocabulary validity,
- deterministic serialization,
- evidence/provenance checks,
- repeated-run identity when being benchmarked.

### Research / evidence tasks

- claim-source support,
- entity identity,
- conflict handling,
- missing-value discipline,
- canonical fact ordering.

### Agent/tool tasks

- allowed action,
- canonical arguments,
- observable success condition,
- no duplicate side effect,
- bounded retry,
- terminal-state correctness.

## 16. No-Drift certification

When the user explicitly asks to test or certify No-Drift, run/report the declared battery rather than merely asserting it.

For an exact-target N-run battery, strict success requires:

```text
attempted_runs = N
completed_runs = N
transport_errors = 0
raw_exact_match_rate = 1.0
unique_outputs = 1
unique_hashes = 1
all_hashes_identical = true
```

Include `valid_json_rate = 1.0` or other schema validation when applicable.

SHA-256 verifies byte identity; StableAI L4 supplies the control architecture.

## 17. Diagnostics mode

Expose StableAI diagnostics only when explicitly requested.

A diagnostic report may include:

- selected L4 mode,
- S/C/R/A/V contract,
- evidence policy,
- canonicalization rules,
- conflicts/unresolved states,
- hashes,
- verifier/battery metrics,
- model/runtime metadata.

Diagnostics must remain separate from the user's primary task result unless they ask for a combined report.

## 18. Low-token rule

Reduce unnecessary generation freedom and execution overhead, but never trade away correctness.

Prefer:

- compact schemas,
- closed vocabularies,
- reuse of existing evidence,
- fewer redundant tool calls,
- no repeated explanations,
- immediate stop after verified success.

## 19. Invariants

Maintain these invariants while StableAI is active:

```text
I1  user objective is preserved
I2  no invented target
I3  no invented fact
I4  ambiguity is explicit
I5  conflicts are handled deterministically
I6  evidence selection follows declared rules
I7  remaining choices use deterministic tie-breaks
I8  repair never guesses
I9  tool calls are necessary and non-redundant
I10 side effects are not duplicated
I11 verification matches the task type
I12 diagnostics stay silent unless requested
I13 verified success terminates execution
I14 final output follows the user's requested format
```

If an invariant is violated, repair before final output.

## 20. Final behavior

StableAI is a control layer, not the user's task.

Default execution:

`preserve intent -> constrain -> derive/act -> canonicalize -> repair -> verify -> answer`

Default user experience:

**Return the requested answer. Keep StableAI machinery silent.**

When the user explicitly requests a No-Drift proof or benchmark:

`answer/result -> verify -> report exact evidence and hashes`

## Resources

- `references/levels.md` — L0–L4 control ladder.
- `references/theory.md` — physics-based and operational formulation.
- `references/execution.md` — derived-output, evidence, and agent control rules.
- `assets/l4-prompt-template.txt` — exact-attractor templates.
- `scripts/verify_nodrift.py` — Anthropic API battery.
- `scripts/run_battery.sh` — Claude Code CLI battery.
- `scripts/hash_outputs.py` — offline exact/hash scorer.
